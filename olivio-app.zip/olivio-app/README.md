# OLÍ VIO — Marketplace Angola → Mundo

App web (PWA) mobile-first de compra e venda com pagamento protegido, em **um único ficheiro** (`index.html`): sem instalação, sem build.

## Como usar
**Testar no computador**
```bash
cd olivio-app
python3 -m http.server 8080      # abra http://localhost:8080
```
**Publicar online (grátis)** — arraste a pasta inteira para um destes:
- **Netlify Drop** → https://app.netlify.com/drop
- **GitHub Pages** (envie os ficheiros para um repositório → Settings → Pages)
- **Vercel** (`vercel` na pasta) ou Cloudflare Pages

Depois de publicado em `https://`, no telemóvel abra o link e use **“Adicionar ao ecrã principal”** para instalar como app (PWA, com ícone e modo offline básico).
> Abrir `index.html` com duplo clique funciona, mas sem instalação PWA.

## Contas
| Tipo | Como entrar |
|---|---|
| **Cliente** | Registar-se na app (a app começa vazia: sem contas nem produtos de exemplo) |
| **Dono** | Email `sudreolivio608@gmail.com` + senha + código OTP (ver abaixo) |

O dono tem painel próprio (Painel, Produtos, Utilizadores, Pagamentos) e o botão **Ver como cliente**.
**Mude a senha/OTP do dono antes de publicar:** `python3 tools/gerar-hash.py` e cole os dois valores no `index.html` (procure `role:'dono'`). O OTP inicial é `1234` — troque-o.

## O que inclui
Login/registo com validação · recuperar senha · 11 idiomas com moeda local (taxas fixas de demonstração) · 25 categorias com ilustrações 3D · fotos reais (galeria + zoom) · chat de negociação com anti-fraude · checkout com Aramex, cupom `OLIVIO10` e endereço · carteira (depositar/sacar), Clube Bronze/Prata/Ouro · pedidos com rastreio e disputa · avaliações · lojas e seguir · favoritos · afiliados · voz na pesquisa · ilha dinâmica · tema claro/escuro · painel do dono com gráficos.

## Limites (leia antes de lançar a sério)
- **Os dados ficam só no aparelho** (`localStorage`). Não há servidor: o que um cliente faz **não aparece** para outro nem para o dono noutro telemóvel.
- **Pagamentos, SMS, push e verificação de BI são simulados.**
- A senha do dono está no ficheiro (cifrada com SHA-256): serve para demonstração. **Em produção, a autenticação tem de ser no servidor.**
- Usa o CDN do Tailwind (precisa de internet na primeira abertura).
- Taxas de câmbio fixas (`CU` no código).

## Próximo passo: ir para produção
1. Crie um projeto em https://supabase.com e execute `supabase/schema.sql` (tabelas, RLS e função `is_owner`).
2. Crie o bucket de Storage `produtos`.
3. Troque o `localStorage` por chamadas `supabase-js` (Auth, tabelas, Realtime para o chat).
4. Ligue um gateway real (Multicaixa Express/Unitel Money/Stripe) e notificações push (OneSignal), sempre com validação **no servidor**.

## Estrutura
```
index.html            app completa
manifest.webmanifest  PWA
sw.js                 modo offline
icons/                ícones 192/512 e favicon
supabase/schema.sql   base de dados + segurança (RLS)
tools/gerar-hash.py   gera hash de senha/OTP do dono
```
© 2026 GRUPO OLÍVIO — Todos os direitos reservados.
