-- OLÍ VIO · esquema inicial para Supabase (ponto de partida)
-- Execute no SQL Editor do seu projeto Supabase.
create extension if not exists "pgcrypto";

create table public.profiles(
  id uuid primary key references auth.users on delete cascade,
  nome text not null, tel text unique, cidade text,
  role text not null default 'cliente' check (role in ('cliente','dono')),
  verificado boolean default false, banido_ate timestamptz,
  saldo numeric(14,2) default 0, pendente numeric(14,2) default 0,
  created_at timestamptz default now());

create table public.products(
  id bigint generated always as identity primary key,
  seller_id uuid references public.profiles on delete cascade,
  titulo text not null check (char_length(titulo)>=10),
  descricao text not null check (char_length(descricao)>=30),
  categoria text not null, provincia text, preco_kz numeric(14,2) not null check (preco_kz between 100 and 100000000),
  imagens text[] default '{}',
  estado text default 'APROVADO_AUTOMATICO',
  pausado boolean default false, vendido boolean default false, destaque_ate timestamptz,
  created_at timestamptz default now());

create table public.orders(
  id text primary key, product_id bigint references public.products, buyer_id uuid references public.profiles,
  valor_kz numeric(14,2) not null, metodo text, estado text default 'Pago',
  endereco text, rastreio text, created_at timestamptz default now());

create table public.reviews(
  id bigint generated always as identity primary key,
  product_id bigint references public.products on delete cascade, user_id uuid references public.profiles,
  nota int check (nota between 1 and 5), comentario text, created_at timestamptz default now(),
  unique(product_id,user_id));

create table public.favorites(user_id uuid references public.profiles on delete cascade, product_id bigint references public.products on delete cascade, primary key(user_id,product_id));
create table public.messages(id bigint generated always as identity primary key, product_id bigint references public.products, sender_id uuid references public.profiles, receiver_id uuid references public.profiles, texto text, oferta_kz numeric(14,2), bloqueada boolean default false, created_at timestamptz default now());
create table public.wallet_ledger(id bigint generated always as identity primary key, user_id uuid references public.profiles, tipo text, valor_kz numeric(14,2), descricao text, created_at timestamptz default now());
create table public.notifications(id bigint generated always as identity primary key, user_id uuid references public.profiles on delete cascade, texto text, lida boolean default false, created_at timestamptz default now());
create table public.fraud_logs(id bigint generated always as identity primary key, user_id uuid, motivo text, created_at timestamptz default now());

create or replace function public.is_owner() returns boolean language sql stable security definer as
$$ select exists(select 1 from public.profiles where id=auth.uid() and role='dono') $$;

-- perfil automático ao registar
create or replace function public.handle_new_user() returns trigger language plpgsql security definer as
$$ begin insert into public.profiles(id,nome,tel,cidade) values(new.id,coalesce(new.raw_user_meta_data->>'nome','Utilizador'),new.raw_user_meta_data->>'tel',new.raw_user_meta_data->>'cidade'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- RLS
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.reviews enable row level security;
alter table public.favorites enable row level security;
alter table public.messages enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.notifications enable row level security;
alter table public.fraud_logs enable row level security;

create policy "perfis visíveis" on public.profiles for select using (true);
create policy "editar o próprio perfil (sem mudar role)" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid() and role=(select role from public.profiles where id=auth.uid()));
create policy "dono gere perfis" on public.profiles for all using (public.is_owner());

create policy "produtos públicos" on public.products for select using ((estado<>'BANIDO' and not pausado and not vendido) or seller_id=auth.uid() or public.is_owner());
create policy "vendedor cria" on public.products for insert with check (seller_id=auth.uid());
create policy "vendedor edita" on public.products for update using (seller_id=auth.uid() or public.is_owner());
create policy "vendedor apaga" on public.products for delete using (seller_id=auth.uid() or public.is_owner());

create policy "comprador vê os seus pedidos" on public.orders for select using (buyer_id=auth.uid() or public.is_owner());
create policy "comprador cria pedido" on public.orders for insert with check (buyer_id=auth.uid());
create policy "dono gere pedidos" on public.orders for update using (public.is_owner());

create policy "avaliações públicas" on public.reviews for select using (true);
create policy "avaliar" on public.reviews for insert with check (user_id=auth.uid());
create policy "favoritos próprios" on public.favorites for all using (user_id=auth.uid());
create policy "mensagens das partes" on public.messages for select using (sender_id=auth.uid() or receiver_id=auth.uid() or public.is_owner());
create policy "enviar mensagem" on public.messages for insert with check (sender_id=auth.uid());
create policy "extrato próprio" on public.wallet_ledger for select using (user_id=auth.uid() or public.is_owner());
create policy "notificações próprias" on public.notifications for all using (user_id=auth.uid());
create policy "só o dono vê fraude" on public.fraud_logs for select using (public.is_owner());

-- Depois de criar a sua conta, promova-a a dono (apenas no SQL Editor):
-- update public.profiles set role='dono' where id=(select id from auth.users where email='o-seu-email');
-- Storage: crie o bucket "produtos" (público para leitura; escrita só autenticados).
