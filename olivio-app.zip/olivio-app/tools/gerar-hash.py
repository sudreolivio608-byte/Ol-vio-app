#!/usr/bin/env python3
"""Gera os hashes (SHA-256) da senha e do OTP do dono para colar em index.html.
Uso: python3 tools/gerar-hash.py
"""
import hashlib,getpass
sha=lambda t:hashlib.sha256(("olivio|"+t).encode()).hexdigest()
pw=getpass.getpass("Nova senha do dono: ")
otp=getpass.getpass("Novo código OTP (4 dígitos): ")
print("\nSubstitua no index.html (procure por role:'dono'):")
print("  ph:'%s'"%sha(pw))
print("  oh:'%s'"%sha(otp))
